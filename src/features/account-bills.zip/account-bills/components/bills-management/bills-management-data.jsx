
export const billstableheading = [
 
    "DOC ID",
    "Bill Recieved via",
    "Vendor",
    "Created By",
    "Created on",
    "Status",
    "Action",
  ];
  
  
  
  export const billstabledata=[
      {
          srno:"01",
          invoiceid:'Email',
          status:'Paid',
          name:'John',
          dateissue:'Doe',
          duedate:'19 Oct,2023',
          amount:'£10245',
      },
      {
          srno:"02",
          invoiceid:'Manual',
          status:'Due',
          name:'Chris',
          dateissue:'Doe',
          duedate:'19 Oct,2023',
          amount:'£10455',
      },
      {
          srno:"03",
          invoiceid:'File Upload',
          status:'Overdue',
          name:'Nick',
          dateissue:'Doe',
          duedate:'19 Oct,2023',
          amount:'£10245',
      },
      {
          srno:"04",
          invoiceid:'File Upload',
          status:'Paid',
          name:'John Doe',
          dateissue:'Doe',
          duedate:'19 Oct,2023',
          amount:'£10245',
      },
      
       
  ]
  
    
  